package com.ayahkeep.app

object PrefsKeys {
    const val PREFS = "ayah_keep_widget"
    const val FOCUS_TEXT = "focus_text"
    const val FOCUS_REF = "focus_ref"
    const val REMINDER_ENABLED = "reminder_enabled"
    const val REMINDER_HOUR = "reminder_hour"
    const val REMINDER_MINUTE = "reminder_minute"
    const val CHANNEL_ID = "ayah_keep_reminders"
    const val REMINDER_REQUEST_CODE = 5001
    const val NOTIFICATION_ID = 7001
}
