package com.ayahkeep.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import org.json.JSONObject

class MainActivity : Activity() {

    private lateinit var web: WebView
    private var pendingExportJson: String? = null
    private var pendingReminder: Pair<Int, Int>? = null

    companion object {
        private const val REQUEST_EXPORT = 1001
        private const val REQUEST_IMPORT = 1002
        private const val REQUEST_NOTIF_PERMISSION = 1003
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.webViewClient = WebViewClient()
        // A real WebChromeClient is required for window.confirm()/alert() dialogs
        // triggered from the page (e.g. delete confirmations) to actually show.
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(AppBridge(), "AndroidBridge")
        web.loadUrl("file:///android_asset/index.html")
        setContentView(web)
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    /** Bridge exposed to the WebView JS: file backups via SAF, widget sync, and reminders. */
    inner class AppBridge {
        @JavascriptInterface
        fun exportBackup(json: String) {
            pendingExportJson = json
            val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "application/json"
                putExtra(Intent.EXTRA_TITLE, "ayah-keep-backup.json")
            }
            @Suppress("DEPRECATION")
            startActivityForResult(intent, REQUEST_EXPORT)
        }

        @JavascriptInterface
        fun importBackup() {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
                putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/json", "text/plain"))
            }
            @Suppress("DEPRECATION")
            startActivityForResult(intent, REQUEST_IMPORT)
        }

        /** Called whenever the focus ayah changes, so the home screen widget stays in sync. */
        @JavascriptInterface
        fun updateFocus(text: String, ref: String) {
            getSharedPreferences(PrefsKeys.PREFS, MODE_PRIVATE).edit()
                .putString(PrefsKeys.FOCUS_TEXT, text)
                .putString(PrefsKeys.FOCUS_REF, ref)
                .apply()
            AyahWidgetProvider.updateAll(this@MainActivity)
        }

        @JavascriptInterface
        fun getReminderState(): String {
            val prefs = getSharedPreferences(PrefsKeys.PREFS, MODE_PRIVATE)
            return JSONObject().apply {
                put("enabled", prefs.getBoolean(PrefsKeys.REMINDER_ENABLED, false))
                put("hour", prefs.getInt(PrefsKeys.REMINDER_HOUR, 20))
                put("minute", prefs.getInt(PrefsKeys.REMINDER_MINUTE, 0))
            }.toString()
        }

        @JavascriptInterface
        fun setReminder(enabled: Boolean, hour: Int, minute: Int) {
            runOnUiThread {
                if (!enabled) {
                    ReminderScheduler.cancel(this@MainActivity)
                    notifyJs("window.__onReminderResult && window.__onReminderResult(true,false)")
                    return@runOnUiThread
                }
                val needsPermission = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                if (needsPermission) {
                    pendingReminder = hour to minute
                    @Suppress("DEPRECATION")
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQUEST_NOTIF_PERMISSION)
                } else {
                    ReminderScheduler.scheduleDaily(this@MainActivity, hour, minute)
                    notifyJs("window.__onReminderResult && window.__onReminderResult(true,true)")
                }
            }
        }
    }

    @Suppress("DEPRECATION")
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_NOTIF_PERMISSION) {
            val granted = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            val pending = pendingReminder
            if (granted && pending != null) {
                ReminderScheduler.scheduleDaily(this, pending.first, pending.second)
            }
            notifyJs("window.__onReminderResult && window.__onReminderResult(true,${granted})")
            pendingReminder = null
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQUEST_EXPORT -> {
                val uri = data?.data
                if (resultCode == RESULT_OK && uri != null) writeExport(uri)
                else notifyJs("window.__onExportDone && window.__onExportDone(false)")
            }
            REQUEST_IMPORT -> {
                val uri = data?.data
                if (resultCode == RESULT_OK && uri != null) readImport(uri)
                else notifyJs("window.__onImportDone && window.__onImportDone(null)")
            }
        }
    }

    private fun writeExport(uri: Uri) {
        val json = pendingExportJson ?: "{}"
        try {
            contentResolver.openOutputStream(uri)?.use { it.write(json.toByteArray(Charsets.UTF_8)) }
            runOnUiThread { Toast.makeText(this, "Backup saved", Toast.LENGTH_SHORT).show() }
            notifyJs("window.__onExportDone && window.__onExportDone(true)")
        } catch (e: Exception) {
            runOnUiThread { Toast.makeText(this, "Could not save backup", Toast.LENGTH_SHORT).show() }
            notifyJs("window.__onExportDone && window.__onExportDone(false)")
        }
    }

    private fun readImport(uri: Uri) {
        try {
            val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }.orEmpty()
            notifyJs("window.__onImportDone && window.__onImportDone(${JSONObject.quote(text)})")
        } catch (e: Exception) {
            notifyJs("window.__onImportDone && window.__onImportDone(null)")
        }
    }

    private fun notifyJs(script: String) {
        runOnUiThread { web.evaluateJavascript(script, null) }
    }
}
