package com.ayahkeep.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class AyahWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        for (id in ids) updateWidget(context, manager, id)
    }

    companion object {
        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, AyahWidgetProvider::class.java))
            for (id in ids) updateWidget(context, manager, id)
        }

        private fun updateWidget(context: Context, manager: AppWidgetManager, id: Int) {
            val prefs = context.getSharedPreferences(PrefsKeys.PREFS, Context.MODE_PRIVATE)
            val text = prefs.getString(PrefsKeys.FOCUS_TEXT, null)
            val ref = prefs.getString(PrefsKeys.FOCUS_REF, "")

            val views = RemoteViews(context.packageName, R.layout.widget_ayah)
            views.setTextViewText(
                R.id.widgetAyah,
                if (text.isNullOrBlank()) "Add an ayah in Ayah Keep to see it here" else text
            )
            views.setTextViewText(R.id.widgetRef, ref ?: "")

            val openApp = Intent(context, MainActivity::class.java)
            val pi = PendingIntent.getActivity(
                context, 0, openApp,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widgetAyah, pi)

            manager.updateAppWidget(id, views)
        }
    }
}
