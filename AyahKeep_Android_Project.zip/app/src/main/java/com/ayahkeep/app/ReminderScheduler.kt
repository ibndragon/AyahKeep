package com.ayahkeep.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.Calendar

object ReminderScheduler {

    private fun pendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, ReminderReceiver::class.java)
        return PendingIntent.getBroadcast(
            context, PrefsKeys.REMINDER_REQUEST_CODE, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun scheduleDaily(context: Context, hour: Int, minute: Int) {
        val prefs = context.getSharedPreferences(PrefsKeys.PREFS, Context.MODE_PRIVATE)
        prefs.edit()
            .putBoolean(PrefsKeys.REMINDER_ENABLED, true)
            .putInt(PrefsKeys.REMINDER_HOUR, hour)
            .putInt(PrefsKeys.REMINDER_MINUTE, minute)
            .apply()

        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            if (before(Calendar.getInstance())) add(Calendar.DAY_OF_YEAR, 1)
        }

        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pendingIntent(context))
    }

    fun cancel(context: Context) {
        val prefs = context.getSharedPreferences(PrefsKeys.PREFS, Context.MODE_PRIVATE)
        prefs.edit().putBoolean(PrefsKeys.REMINDER_ENABLED, false).apply()
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pendingIntent(context))
    }
}
