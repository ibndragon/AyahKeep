package com.ayahkeep.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED) return
        val prefs = context.getSharedPreferences(PrefsKeys.PREFS, Context.MODE_PRIVATE)
        if (prefs.getBoolean(PrefsKeys.REMINDER_ENABLED, false)) {
            ReminderScheduler.scheduleDaily(
                context,
                prefs.getInt(PrefsKeys.REMINDER_HOUR, 20),
                prefs.getInt(PrefsKeys.REMINDER_MINUTE, 0)
            )
        }
    }
}
