package com.ayahkeep.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Notification
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val prefs = context.getSharedPreferences(PrefsKeys.PREFS, Context.MODE_PRIVATE)
        val text = prefs.getString(PrefsKeys.FOCUS_TEXT, null)
        val ref = prefs.getString(PrefsKeys.FOCUS_REF, "")

        val body = if (text.isNullOrBlank()) "Open Ayah Keep to add an ayah to memorize." else text
        val title = if (ref.isNullOrBlank()) "Time to review your ayah" else "Review: $ref"

        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                PrefsKeys.CHANNEL_ID,
                "Memorization reminders",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            nm.createNotificationChannel(channel)
        }

        val openApp = Intent(context, MainActivity::class.java)
        val pi = PendingIntent.getActivity(
            context, 0, openApp,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(context, PrefsKeys.CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(context)
        }
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(Notification.BigTextStyle().bigText(body))
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()

        nm.notify(PrefsKeys.NOTIFICATION_ID, notification)

        // Re-schedule for the same time tomorrow (AlarmManager alarms are one-shot here).
        if (prefs.getBoolean(PrefsKeys.REMINDER_ENABLED, false)) {
            ReminderScheduler.scheduleDaily(
                context,
                prefs.getInt(PrefsKeys.REMINDER_HOUR, 20),
                prefs.getInt(PrefsKeys.REMINDER_MINUTE, 0)
            )
        }
    }
}
