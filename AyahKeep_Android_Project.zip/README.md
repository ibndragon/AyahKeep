# Ayah Keep — Android APK Project

Offline-first Android app for personal Quran ayah memorization.

## Architecture
- Native Android shell (Kotlin)
- Local HTML/CSS/JS interface bundled inside the APK
- `localStorage` / WebView DOM storage for local records
- No INTERNET permission
- No account, backend, Firebase, analytics, or central database
- Export/Restore JSON backup for moving a user's data to another phone

## Build
Open this folder in Android Studio and let Gradle sync.
Then use:
Build > Build Bundle(s) / APK(s) > Build APK(s)

For a release APK, create/sign a release build in Android Studio.

## Data model
Each installation has its own local data:
- ayah text
- reference
- note
- memorized status
- memorization dates
- current focus index

The app does not transmit this data anywhere.
